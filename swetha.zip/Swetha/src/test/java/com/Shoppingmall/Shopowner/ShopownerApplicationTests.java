package com.Shoppingmall.Shopowner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopownerApplicationTests {

	@Test
	void contextLoads() {
	}

}
